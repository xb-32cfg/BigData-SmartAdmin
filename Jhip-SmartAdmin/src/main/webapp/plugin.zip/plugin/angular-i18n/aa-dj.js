require('./angular-locale_aa-dj');
module.exports = 'ngLocale';
