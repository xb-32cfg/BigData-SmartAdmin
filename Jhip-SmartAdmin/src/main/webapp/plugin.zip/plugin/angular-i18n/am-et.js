require('./angular-locale_am-et');
module.exports = 'ngLocale';
